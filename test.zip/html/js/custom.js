// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2018 15:37:25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

// Get todays date and time
var now = new Date().getTime();

// Find the distance between now an the count down date
var distance = countDownDate - now;

// Time calculations for days, hours, minutes and seconds
var days = Math.floor(distance / (1000 * 60 * 60 * 24));
var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((distance % (1000 * 60)) / 1000);

// Output the result in an element with id="demo"
document.getElementById("demo1").innerHTML = "<div class='block'>" + "<div class='toptext'>" + days + "</div>" + "<span>Days</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + hours + "</div>" + "<span>hours</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + minutes + "</div>" + "<span>Mins</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + seconds + "</div>" + "<span>Secs</span>" + "</div>";

document.getElementById("demo2").innerHTML = "<div class='block'>" + "<div class='toptext'>" + days + "</div>" + "<span>Days</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + hours + "</div>" + "<span>hours</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + minutes + "</div>" + "<span>Mins</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + seconds + "</div>" + "<span>Secs</span>" + "</div>";

document.getElementById("demo3").innerHTML = "<div class='block'>" + "<div class='toptext'>" + days + "</div>" + "<span>Days</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + hours + "</div>" + "<span>hours</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + minutes + "</div>" + "<span>Mins</span>" + "</div>" + "<div class='block'>" + "<div class='toptext'>" + seconds + "</div>" + "<span>Secs</span>" + "</div>";

// If the count down is over, write some text 
if (distance < 0) {
clearInterval(x);
document.getElementById("demo").innerHTML = "EXPIRED";
}
}, 1000);

/*BX Slider*/

$(document).ready(function(){
$('#slider1').bxSlider({
controls: false,
auto: true,
pause: 2000
});


var windowsize = $(window).width();


if (windowsize < 550) {
$('#slider2').bxSlider({
auto: true,
nextText: '<i class="fa  fa-angle-right" aria-hidden="true"></i>',
prevText: '<i class="fa  fa-angle-left" aria-hidden="true"></i>',
swipeThreshold: 50,
oneToOneTouch: true,
preventDefaultSwipeX: true,
preventDefaultSwipeY: false,
slideWidth: 400,
minSlides: 1,
maxSlides: 1,
moveSlides: 1,
slideMargin: 0,
pager:false,
controls: true,
autoHover: true
});
}if (windowsize < 980) {
$('#slider2').bxSlider({
auto: true,
nextText: '<i class="fa  fa-angle-right" aria-hidden="true"></i>',
prevText: '<i class="fa  fa-angle-left" aria-hidden="true"></i>',
swipeThreshold: 50,
oneToOneTouch: true,
preventDefaultSwipeX: true,
preventDefaultSwipeY: false,
slideWidth: 320,
minSlides: 2,
maxSlides: 3,
moveSlides: 2,
slideMargin: 0,
pager:false,
controls: true,
autoHover: true
});

} if (windowsize < 1200) {
$('#slider2').bxSlider({
auto: true,
nextText: '<i class="fa  fa-angle-right" aria-hidden="true"></i>',
prevText: '<i class="fa  fa-angle-left" aria-hidden="true"></i>',
swipeThreshold: 50,
oneToOneTouch: true,
preventDefaultSwipeX: true,
preventDefaultSwipeY: false,
slideWidth: 365,
minSlides: 2,
maxSlides: 4,
moveSlides: 4,
slideMargin: 0,
pager:false,
controls: true,
autoHover: true
});

} else {
$('#slider2').bxSlider({
auto: true,
nextText: '<i class="fa  fa-angle-right" aria-hidden="true"></i>',
prevText: '<i class="fa  fa-angle-left" aria-hidden="true"></i>',
swipeThreshold: 50,
oneToOneTouch: true,
preventDefaultSwipeX: true,
preventDefaultSwipeY: false,
slideWidth: 320,
minSlides: 1,
maxSlides: 5,
moveSlides: 5,
slideMargin: 0,
pager:false,
controls: true,
autoHover: true
});
}

$('.slider3').bxSlider({
nextText: '<i class="fa  fa-angle-right" aria-hidden="true"></i>',
prevText: '<i class="fa  fa-angle-left" aria-hidden="true"></i>',
auto: true,
autoHover: true,
pause: 2000,
controls: true,
pager:false,
});

});

/*BX Slider*/

$(document).ready(function(){
$(".mobile-menu-icon").click(function(){
$(this).toggleClass("active");	
});
$(".mobile-top-links").click(function(){
$(".top-links ul").toggleClass("active");	
$(this).toggleClass("open");	
});

$(".footer-menu").click(function(){
$(".footer-menu").removeClass("active");	
$(this).toggleClass("active");	
});
});


/*tab js*/
$(".tab_content").hide();
$(".tab_content:first").show();

/* if in tab mode */
$("ul.tabs li").click(function() {

$(".tab_content").hide();
var activeTab = $(this).attr("rel"); 
$("#"+activeTab).fadeIn();		

$("ul.tabs li").removeClass("active");
$(this).addClass("active");

$(".tab_drawer_heading").removeClass("d_active");
$(".tab_drawer_heading[rel^='"+activeTab+"']").addClass("d_active");

});
/* if in drawer mode */
$(".tab_drawer_heading").click(function() {

$(".tab_content").hide();
var d_activeTab = $(this).attr("rel"); 
$("#"+d_activeTab).fadeIn();

$(".tab_drawer_heading").removeClass("d_active");
$(this).addClass("d_active");

$("ul.tabs li").removeClass("active");
$("ul.tabs li[rel^='"+d_activeTab+"']").addClass("active");
});


$('ul.tabs li').last().addClass("tab_last");